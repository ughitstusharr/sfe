import { useState } from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Layout from '@/components/Layout';
import { UserProfile } from '@clerk/clerk-react';

// Example user games data for the dashboard
const userGames = [
  {
    id: "office-maze",
    title: "Office Maze",
    description: "Navigate through the labyrinth of cubicles to find the coffee machine before the meeting starts!",
    category: "Puzzle",
    plays: 126,
    lastUpdated: "2023-07-15T10:30:00Z",
    published: true
  },
  {
    id: "keyboard-ninja",
    title: "Keyboard Ninja",
    description: "Test your typing speed by slicing flying emails with accurate keystrokes.",
    category: "Action",
    plays: 78,
    lastUpdated: "2023-07-08T14:45:00Z",
    published: true
  },
  {
    id: "project-panic",
    title: "Project Panic",
    description: "Deadline approaching! Collect all project resources while avoiding the angry manager.",
    category: "Platformer",
    plays: 0,
    lastUpdated: "2023-07-20T16:20:00Z",
    published: false
  }
];

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('games');
  
  // Format date string
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    }).format(date);
  };

  return (
    <Layout>
      <div className="bg-slate-50 min-h-screen pb-20">
        <div className="bg-primary/10 py-12">
          <div className="max-w-7xl mx-auto px-4">
            <h1 className="text-3xl font-bold text-slate-800">Your Dashboard</h1>
            <p className="text-slate-600 mt-2">Manage your games and account</p>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 mt-6">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Main content area */}
            <div className="flex-1">
              {/* Tabs */}
              <div className="flex border-b border-slate-200 mb-6">
                <button 
                  onClick={() => setActiveTab('games')}
                  className={`px-4 py-2 font-medium text-sm ${activeTab === 'games' 
                    ? 'text-primary border-b-2 border-primary' 
                    : 'text-slate-600 hover:text-slate-900'}`}
                >
                  My Games
                </button>
                <button 
                  onClick={() => setActiveTab('stats')}
                  className={`px-4 py-2 font-medium text-sm ${activeTab === 'stats' 
                    ? 'text-primary border-b-2 border-primary' 
                    : 'text-slate-600 hover:text-slate-900'}`}
                >
                  Statistics
                </button>
                <button 
                  onClick={() => setActiveTab('profile')}
                  className={`px-4 py-2 font-medium text-sm ${activeTab === 'profile' 
                    ? 'text-primary border-b-2 border-primary' 
                    : 'text-slate-600 hover:text-slate-900'}`}
                >
                  Profile
                </button>
              </div>
              
              {/* Games tab content */}
              {activeTab === 'games' && (
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-semibold text-slate-800">Your Games</h2>
                    <Link href="/create">
                      <Button className="bg-primary hover:bg-primary/90">
                        <i className="ri-add-line mr-1"></i> Create New Game
                      </Button>
                    </Link>
                  </div>
                  
                  {userGames.length === 0 ? (
                    <Card className="bg-white border border-slate-200">
                      <CardContent className="pt-10 pb-10 flex flex-col items-center justify-center">
                        <div className="bg-slate-100 p-4 rounded-full mb-4">
                          <i className="ri-gamepad-line text-4xl text-slate-400"></i>
                        </div>
                        <h3 className="text-lg font-semibold text-slate-700 mb-2">No games yet</h3>
                        <p className="text-slate-500 text-center max-w-md mb-6">
                          You haven't created any games yet. Start by creating your first game!
                        </p>
                        <Link href="/create">
                          <Button className="bg-primary hover:bg-primary/90">Create Your First Game</Button>
                        </Link>
                      </CardContent>
                    </Card>
                  ) : (
                    <div className="grid gap-4">
                      {userGames.map((game) => (
                        <Card key={game.id} className="bg-white border border-slate-200 overflow-hidden">
                          <div className="flex flex-col md:flex-row">
                            <div className="md:w-48 h-32 md:h-auto bg-slate-200"></div>
                            <div className="flex-1 p-5">
                              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                                <div>
                                  <div className="flex items-center mb-2">
                                    <h3 className="font-bold text-lg mr-3">{game.title}</h3>
                                    <Badge variant={game.published ? 'green' : 'yellow'}>
                                      {game.published ? 'Published' : 'Draft'}
                                    </Badge>
                                  </div>
                                  <p className="text-slate-600 text-sm mb-4">{game.description}</p>
                                </div>
                                <div className="mt-4 md:mt-0 shrink-0 md:ml-4">
                                  <div className="flex gap-2">
                                    <Link href={`/edit/${game.id}`}>
                                      <Button variant="outline" size="sm">
                                        <i className="ri-edit-line mr-1"></i> Edit
                                      </Button>
                                    </Link>
                                    <Link href={`/play/${game.id}`}>
                                      <Button className="bg-primary hover:bg-primary/90" size="sm">
                                        <i className="ri-gamepad-line mr-1"></i> Play
                                      </Button>
                                    </Link>
                                  </div>
                                </div>
                              </div>
                              <div className="flex flex-wrap gap-4 mt-4 text-sm text-slate-500">
                                <div className="flex items-center">
                                  <i className="ri-game-line mr-1"></i>
                                  <span>{game.plays} {game.plays === 1 ? 'play' : 'plays'}</span>
                                </div>
                                <div className="flex items-center">
                                  <i className="ri-calendar-line mr-1"></i>
                                  <span>Updated {formatDate(game.lastUpdated)}</span>
                                </div>
                                <div className="flex items-center">
                                  <i className="ri-price-tag-3-line mr-1"></i>
                                  <span>{game.category}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              )}
              
              {/* Stats tab content */}
              {activeTab === 'stats' && (
                <div>
                  <h2 className="text-xl font-semibold text-slate-800 mb-6">Game Statistics</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-slate-500">Total Plays</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold">204</div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-slate-500">Games Created</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold">3</div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-slate-500">Avg. Rating</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold">4.7</div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Play History</CardTitle>
                      <CardDescription>Total plays over time</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-[300px] flex items-center justify-center bg-slate-50 rounded-md border border-slate-200">
                        <p className="text-slate-500">Chart visualization would be displayed here</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
              
              {/* Profile tab content */}
              {activeTab === 'profile' && (
                <div>
                  <h2 className="text-xl font-semibold text-slate-800 mb-6">Your Profile</h2>
                  <Card>
                    <CardContent className="pt-6">
                      <UserProfile
                        appearance={{
                          elements: {
                            rootBox: "",
                            card: "bg-transparent shadow-none p-0",
                            navbar: "hidden",
                            pageScrollBox: "p-0"
                          }
                        }}
                      />
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
            
            {/* Sidebar */}
            <div className="w-full md:w-80 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quick Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Total Games</span>
                    <span className="font-semibold">{userGames.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Published</span>
                    <span className="font-semibold">{userGames.filter(g => g.published).length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Drafts</span>
                    <span className="font-semibold">{userGames.filter(g => !g.published).length}</span>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Get More Players</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 text-sm mb-4">
                    Share your games with coworkers to increase your play count and get feedback.
                  </p>
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    <i className="ri-share-line mr-1"></i> Share Your Games
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Need Help?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 text-sm mb-4">
                    Check out our resources for creating engaging games.
                  </p>
                  <div className="space-y-2">
                    <Link href="/tutorials" className="text-primary hover:text-primary/90 flex items-center">
                      <i className="ri-book-read-line mr-2"></i> Tutorials
                    </Link>
                    <Link href="/documentation" className="text-primary hover:text-primary/90 flex items-center">
                      <i className="ri-file-list-3-line mr-2"></i> Documentation
                    </Link>
                    <Link href="/community" className="text-primary hover:text-primary/90 flex items-center">
                      <i className="ri-group-line mr-2"></i> Community Forums
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

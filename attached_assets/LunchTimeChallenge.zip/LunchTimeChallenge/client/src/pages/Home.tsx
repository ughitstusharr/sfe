import { Link } from 'wouter';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';

export default function Home() {
  return (
    <Layout isLandingPage={true}>
      <div className="bg-gradient-to-b from-slate-50 to-slate-100">
        {/* Hero Section */}
        <div className="relative bg-gradient-to-r from-purple-500/10 to-cyan-400/10 pt-24 pb-20 overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute -top-20 -right-20 w-80 h-80 bg-cyan-400 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-20 w-80 h-80 bg-purple-600 rounded-full blur-3xl"></div>
          </div>
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-slate-800 mb-8">
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-violet-500">
                  Secure File Sharing
                </span>
                <br /> For Teams
              </h1>
              <p className="text-xl md:text-2xl text-slate-600 mb-12 max-w-3xl mx-auto">
                Share encrypted files with your teammates during lunch breaks. Fast, secure, and simple.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/sign-up">
                  <Button className="text-lg h-14 px-8 bg-gradient-to-r from-purple-600 to-violet-500 hover:from-purple-700 hover:to-violet-600 shadow-md">
                    Get Started
                  </Button>
                </Link>
                <Link href="/sign-in">
                  <Button variant="outline" className="text-lg h-14 px-8 border-slate-300 text-slate-700 hover:bg-slate-100">
                    Sign In
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        {/* How It Works Section */}
        <div className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-slate-800 mb-4">How It Works</h2>
              <p className="text-lg text-slate-600 max-w-3xl mx-auto">
                SecureShare makes file sharing simple, secure, and straightforward.
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-10 max-w-5xl mx-auto">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 mb-6">
                  <i className="ri-upload-cloud-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-2">Upload & Encrypt</h3>
                <p className="text-slate-600">
                  Upload your file and encrypt it with a password only you and your recipient know.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 mb-6">
                  <i className="ri-link-m text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-2">Share the Link</h3>
                <p className="text-slate-600">
                  Share the generated link with your teammates through your preferred channel.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 mb-6">
                  <i className="ri-lock-unlock-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-2">Decrypt & Access</h3>
                <p className="text-slate-600">
                  Recipients use the password to decrypt and access the file directly in their browser.
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Features Section */}
        <div className="py-20 bg-gradient-to-b from-purple-50 to-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-slate-800 mb-4">Built for Security</h2>
              <p className="text-lg text-slate-600 max-w-3xl mx-auto">
                Our platform prioritizes your data security and privacy at every step.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: "ri-shield-check-line",
                  title: "End-to-End Encryption",
                  description: "Files are encrypted in your browser before upload, so even we can't access the content."
                },
                {
                  icon: "ri-timer-line",
                  title: "Expiring Links",
                  description: "Set expiration dates for shared files to ensure they don't remain accessible indefinitely."
                },
                {
                  icon: "ri-spy-line",
                  title: "No Tracking",
                  description: "We don't track or analyze the contents of your encrypted files."
                },
                {
                  icon: "ri-file-lock-line",
                  title: "Password Protection",
                  description: "Every file is protected with a password that's never stored on our servers."
                },
                {
                  icon: "ri-secure-payment-line",
                  title: "Secure Storage",
                  description: "Files are stored in a secure database with industry-standard protection."
                },
                {
                  icon: "ri-eye-off-line",
                  title: "Privacy First",
                  description: "Your privacy is our priority, with no unnecessary data collection."
                }
              ].map((feature, index) => (
                <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex">
                  <div className="mr-5 mt-1 w-10 h-10 bg-purple-100 rounded-full flex-shrink-0 flex items-center justify-center text-purple-600">
                    <i className={`${feature.icon} text-xl`}></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-800 mb-2">{feature.title}</h3>
                    <p className="text-slate-600">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* CTA Section */}
        <div className="py-20 bg-gradient-to-r from-purple-500/10 to-cyan-400/10 relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-400 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-80 h-80 bg-purple-600 rounded-full blur-3xl"></div>
          </div>
          
          <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center relative z-10">
            <h2 className="text-3xl font-bold text-slate-800 mb-6">Ready to share files securely?</h2>
            <p className="text-lg text-slate-600 mb-10">
              Join SecureShare today and experience the easiest way to share files securely with your team.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/sign-up">
                <Button className="text-lg h-14 px-8 bg-gradient-to-r from-purple-600 to-violet-500 hover:from-purple-700 hover:to-violet-600 shadow-md">
                  Create Your Account
                </Button>
              </Link>
              <Link href="/file-share">
                <Button variant="outline" className="text-lg h-14 px-8 border-slate-300 text-slate-700 hover:bg-purple-50 hover:border-purple-200 hover:text-purple-700">
                  Try It Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

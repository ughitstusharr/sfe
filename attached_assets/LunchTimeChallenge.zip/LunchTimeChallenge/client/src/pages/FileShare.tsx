import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from "@/lib/queryClient";
import { useQuery } from '@tanstack/react-query';

export default function FileShare() {
  const [file, setFile] = useState<File | null>(null);
  const [password, setPassword] = useState('');
  const [link, setLink] = useState('');
  const [loading, setLoading] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Check if user is authenticated and get their files
  const { data: userFiles, isLoading: isLoadingFiles } = useQuery<any[]>({
    queryKey: ['/api/files']
  });
  
  // Redirect to login if authentication fails
  useEffect(() => {
    const checkAuth = async () => {
      try {
        await apiRequest("GET", "/api/files");
      } catch (error) {
        toast({
          title: "Authentication required",
          description: "Please sign in to continue",
          variant: "destructive"
        });
        setLocation('/sign-in');
      }
    };
    
    checkAuth();
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      toast({
        title: "File selected",
        description: `${e.target.files[0].name} (${(e.target.files[0].size / 1024 / 1024).toFixed(2)} MB)`,
        duration: 3000
      });
    }
  };

  useEffect(() => {
    // Simple password strength calculator
    if (!password) {
      setPasswordStrength(0);
      return;
    }
    
    let strength = 0;
    if (password.length >= 8) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;
    
    setPasswordStrength(strength);
  }, [password]);

  const handleUpload = async () => {
    if (!file || !password) {
      toast({
        title: "Missing information",
        description: "Both file and password are required",
        variant: "destructive"
      });
      return;
    }
   
    setLoading(true);
   
    try {
      // Read the file as text
      const fileContent = await readFileAsText(file);
      
      // Simple encryption using a password-based key
      // This is a basic implementation - in production you'd use a more robust encryption
      const encryptedContent = simpleEncrypt(fileContent, password);
      
      // Set expiration date to 7 days from now
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);
      
      // Upload the encrypted file to the server
      const response = await apiRequest("POST", "/api/files", {
        fileName: file.name,
        encryptedContent,
        expiresAt: expiresAt.toISOString()
      });
      
      const fileData = await response.json();
      
      // Generate the share link
      setLink(`${window.location.origin}/api/share/${fileData.accessKey}`);
      
      toast({
        title: "Upload successful",
        description: "Your file has been encrypted and uploaded",
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "There was an error uploading your file",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Simple encryption function using XOR
  const simpleEncrypt = (text: string, password: string): string => {
    let result = '';
    const passwordLength = password.length;
    
    for (let i = 0; i < text.length; i++) {
      // XOR each character with a character from the password
      const textCharCode = text.charCodeAt(i);
      const passwordCharCode = password.charCodeAt(i % passwordLength);
      const encryptedCharCode = textCharCode ^ passwordCharCode;
      
      // Convert to a string representation that can be stored
      result += encryptedCharCode.toString(16).padStart(4, '0');
    }
    
    return result;
  };
  
  // Helper function to read file as text
  const readFileAsText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  };

  return (
    <Layout>
      <div className="bg-gradient-to-b from-slate-50 to-slate-100 min-h-screen pb-20">
        <div className="bg-gradient-to-r from-purple-500/20 to-cyan-400/10 py-12 relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-cyan-400 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-20 w-40 h-40 bg-purple-600 rounded-full blur-3xl"></div>
          </div>
          <div className="max-w-7xl mx-auto px-4 relative z-10">
            <h1 className="text-3xl md:text-4xl font-bold text-slate-800">Secure File Sharing</h1>
            <p className="text-slate-600 mt-2 max-w-xl">
              Encrypt and securely share files with teammates during lunch breaks
            </p>
          </div>
        </div>
        
        <div className="max-w-3xl mx-auto px-4 pt-8 pb-16 -mt-6 relative z-20">
          <Card className="shadow-lg border border-slate-200 overflow-hidden bg-white/80 backdrop-blur-sm">
            <CardHeader className="pb-0 pt-6 px-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle className="text-2xl font-bold">File Encryption</CardTitle>
                  <CardDescription className="text-slate-500 mt-1">
                    Upload a file, encrypt it, and share securely
                  </CardDescription>
                </div>
                <Badge 
                  className="bg-purple-100 text-purple-800 px-3 py-1 text-xs flex items-center self-start md:self-auto"
                >
                  <i className="ri-shield-check-line mr-1"></i> End-to-End Encrypted
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="px-6 pt-6">
              <div className="space-y-6">
                <div 
                  className={`relative border-2 border-dashed rounded-xl p-10 transition-all cursor-pointer
                    ${file ? 'border-purple-400/40 bg-purple-50/50' : 'border-slate-200 bg-white hover:bg-slate-50'}`}
                >
                  <input
                    type="file"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <div className="text-center">
                    <div className="flex justify-center">
                      <div className={`w-20 h-20 rounded-full flex items-center justify-center
                        ${file 
                          ? 'bg-purple-100 text-purple-600 animate-pulse-slow' 
                          : 'bg-slate-100 text-slate-400'
                        }`}>
                        {file ? (
                          <i className="ri-file-lock-line text-3xl"></i>
                        ) : (
                          <i className="ri-upload-cloud-line text-3xl"></i>
                        )}
                      </div>
                    </div>
                    <h3 className="mt-4 font-medium text-slate-800">
                      {file ? file.name : "Drop your file here"}
                    </h3>
                    <p className="mt-2 text-sm text-slate-500">
                      {file 
                        ? `${(file.size / 1024 / 1024).toFixed(2)} MB · Selected for encryption` 
                        : "or click to browse your device"
                      }
                    </p>
                  </div>
                </div>
               
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label htmlFor="password" className="block text-sm font-medium text-slate-700">
                      Encryption Password
                    </label>
                    {password && (
                      <div className="flex items-center gap-1">
                        <div className={`h-1.5 w-5 rounded-full ${
                          passwordStrength >= 1 ? 'bg-orange-500' : 'bg-slate-200'
                        }`}></div>
                        <div className={`h-1.5 w-5 rounded-full ${
                          passwordStrength >= 2 ? 'bg-yellow-500' : 'bg-slate-200'
                        }`}></div>
                        <div className={`h-1.5 w-5 rounded-full ${
                          passwordStrength >= 3 ? 'bg-cyan-500' : 'bg-slate-200'
                        }`}></div>
                        <div className={`h-1.5 w-5 rounded-full ${
                          passwordStrength >= 4 ? 'bg-purple-600' : 'bg-slate-200'
                        }`}></div>
                        <span className={`text-xs ml-1 ${
                          passwordStrength === 0 ? 'text-slate-500' :
                          passwordStrength === 1 ? 'text-orange-600' :
                          passwordStrength === 2 ? 'text-yellow-600' :
                          passwordStrength === 3 ? 'text-cyan-600' :
                          'text-purple-600'
                        }`}>
                          {passwordStrength === 0 && "Weak"}
                          {passwordStrength === 1 && "Fair"}
                          {passwordStrength === 2 && "Good"}
                          {passwordStrength === 3 && "Strong"}
                          {passwordStrength === 4 && "Very Strong"}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      id="password"
                      type="password"
                      placeholder="Enter a secure password"
                      className="pl-10 pr-4 py-3 w-full rounded-lg border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                      <i className="ri-lock-line"></i>
                    </div>
                  </div>
                  <p className="mt-2 text-xs text-slate-500">
                    Use a combination of letters, numbers, and special characters
                  </p>
                </div>
               
                <div className="pt-4">
                  <Button
                    onClick={handleUpload}
                    disabled={loading || !file || !password}
                    className={`w-full h-12 text-base shadow-md transition-all 
                      ${loading || !file || !password 
                        ? 'bg-slate-300 cursor-not-allowed opacity-70' 
                        : 'bg-gradient-to-r from-purple-600 to-violet-500 hover:shadow-lg'}`}
                  >
                    {loading ? (
                      <span className="flex items-center">
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Encrypting & Uploading...
                      </span>
                    ) : (
                      <span className="flex items-center justify-center">
                        <i className="ri-lock-password-line mr-2"></i>
                        Encrypt & Upload
                      </span>
                    )}
                  </Button>
                </div>
              </div>
              
              {link && (
                <div className="mt-8 pt-6 border-t border-slate-200">
                  <div className="rounded-xl bg-gradient-to-br from-purple-100/50 to-cyan-50/50 p-5 border border-purple-200">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-600">
                          <i className="ri-link-m"></i>
                        </div>
                        <h3 className="font-medium text-slate-800">Secure Link Generated</h3>
                      </div>
                      <Badge className="bg-gradient-to-r from-purple-600 to-violet-500 text-white">Ready to Share</Badge>
                    </div>
                    
                    <div className="bg-white/90 p-4 rounded-lg border border-slate-200 flex items-center justify-between group">
                      <code className="text-sm text-cyan-700 font-mono overflow-x-auto flex-1 mr-2">
                        {link}
                      </code>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          navigator.clipboard.writeText(link);
                          toast({
                            title: "Link copied",
                            description: "Secure link copied to clipboard",
                            duration: 3000
                          });
                        }}
                        className="shrink-0 group-hover:border-purple-500 group-hover:text-purple-600 transition-colors"
                      >
                        <i className="ri-file-copy-line mr-1"></i>
                        Copy
                      </Button>
                    </div>
                    
                    <div className="flex justify-between items-center mt-4">
                      <p className="text-xs text-slate-500">
                        Share this link and the password separately for better security
                      </p>
                      <Link href={link} target="_blank">
                        <Button variant="outline" size="sm" className="text-purple-600 border-purple-300 hover:bg-purple-50">
                          <i className="ri-external-link-line mr-1"></i>
                          Open
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="mt-6 rounded-xl bg-gradient-to-br from-purple-50 to-indigo-50 p-4 text-purple-900 text-sm flex items-start border border-purple-100">
                <div className="mr-3 mt-0.5 bg-purple-100 text-purple-700 rounded-full p-1">
                  <i className="ri-information-line text-lg"></i>
                </div>
                <div>
                  <p className="font-medium">How secure file sharing works:</p>
                  <ol className="mt-1 list-decimal ml-5 space-y-1">
                    <li>Upload your file and set a strong password</li>
                    <li>Your file is encrypted in your browser before uploading</li>
                    <li>Share the generated link and password separately</li>
                    <li>Recipients need both the link and password to access the file</li>
                  </ol>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {userFiles && userFiles.length > 0 && (
        <div className="max-w-3xl mx-auto px-4 pt-8 relative z-20">
          <Card className="shadow-lg border border-slate-200 overflow-hidden bg-white/80 backdrop-blur-sm mt-8">
            <CardHeader className="pb-2 pt-6 px-6">
              <CardTitle className="text-xl font-bold">Your Files</CardTitle>
              <CardDescription className="text-slate-500">
                Files you've previously shared
              </CardDescription>
            </CardHeader>
            <CardContent className="px-6 pt-4 pb-6">
              <div className="divide-y divide-slate-200">
                {userFiles.map((file) => (
                  <div key={file.id} className="py-4 first:pt-0 last:pb-0">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600">
                          <i className="ri-file-lock-line text-xl"></i>
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-800 truncate max-w-[200px]">
                            {file.fileName}
                          </h3>
                          <p className="text-xs text-slate-500">
                            {new Date(file.createdAt).toLocaleDateString()} • {file.downloads} downloads
                          </p>
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-purple-600 border-purple-300 hover:bg-purple-50"
                        onClick={() => {
                          navigator.clipboard.writeText(`${window.location.origin}/api/share/${file.accessKey}`);
                          toast({
                            title: "Link copied",
                            description: "Share link copied to clipboard",
                            duration: 3000
                          });
                        }}
                      >
                        <i className="ri-link-m mr-1"></i>
                        Copy Link
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </Layout>
  );
}
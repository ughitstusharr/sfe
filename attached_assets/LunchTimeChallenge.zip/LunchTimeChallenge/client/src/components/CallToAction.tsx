import { Link } from 'wouter';

export default function CallToAction() {
  return (
    <section className="py-16 px-4 bg-gradient-to-r from-primary to-primary-600 text-white">
      <div className="max-w-7xl mx-auto text-center">
        <h2 className="text-3xl font-bold font-game mb-4">Ready to Turn Your Lunch Break into Game Time?</h2>
        <p className="text-primary-50 max-w-2xl mx-auto mb-8 text-lg">
          Join thousands of coworkers who are already creating, sharing, and playing custom game levels during their breaks.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/sign-up" className="px-8 py-3 bg-white text-primary font-medium rounded-lg shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
            Create Your Account
          </Link>
          <Link href="/discover" className="px-8 py-3 bg-transparent hover:bg-primary-400 text-white font-medium rounded-lg border-2 border-white transition-all">
            Browse Games First
          </Link>
        </div>
      </div>
    </section>
  );
}

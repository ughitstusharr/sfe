'use client'
import { useAuth } from '@clerk/clerk-react'
import { useEffect } from 'react'
import { useLocation } from 'wouter'

export default function AuthRedirect() {
  const { isSignedIn, isLoaded } = useAuth()
  const [, setLocation] = useLocation()
  
  useEffect(() => {
    if (isLoaded && isSignedIn) {
      setLocation('/dashboard')
    }
  }, [isLoaded, isSignedIn, setLocation])
  
  return null // This component doesn't render anything
}

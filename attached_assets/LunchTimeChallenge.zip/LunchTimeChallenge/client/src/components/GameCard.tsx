import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Link } from 'wouter';

interface GameCardProps {
  id: string;
  title: string;
  description: string;
  category: string;
  rating: number;
  creatorName: string;
  imageUrl?: string;
}

export default function GameCard({ id, title, description, category, rating, creatorName, imageUrl }: GameCardProps) {
  // Map category to badge color
  const categoryColors: Record<string, string> = {
    'Platformer': 'blue',
    'Puzzle': 'purple',
    'Racing': 'red',
    'Adventure': 'green',
    'Strategy': 'yellow'
  };
  
  const badgeColor = categoryColors[category] || 'blue';
  
  return (
    <Card className="overflow-hidden group border border-slate-200">
      <div className="relative h-48 w-full overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black/10 to-black/30 z-10"></div>
        <div 
          className="w-full h-full bg-slate-200 group-hover:scale-105 transition-transform duration-300"
          style={{
            backgroundImage: imageUrl ? `url(${imageUrl})` : 'none',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
      </div>
      <div className="p-5">
        <div className="flex items-center justify-between mb-3">
          <Badge variant={badgeColor as any} className="px-3 py-1 text-xs">{category}</Badge>
          <div className="flex items-center">
            <i className="ri-star-fill text-yellow-400 mr-1"></i>
            <span className="text-slate-700 text-sm">{rating.toFixed(1)}</span>
          </div>
        </div>
        <h3 className="font-game font-bold text-xl mb-2">{title}</h3>
        <p className="text-slate-600 text-sm mb-4 line-clamp-2">{description}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center mr-2 text-xs">
              {creatorName.charAt(0).toUpperCase()}
            </div>
            <span className="text-sm text-slate-500">by {creatorName}</span>
          </div>
          <Link href={`/play/${id}`} className="text-white bg-primary hover:bg-primary/90 px-4 py-1.5 rounded-lg text-sm font-medium transition-colors">
            Play Now
          </Link>
        </div>
      </div>
    </Card>
  );
}

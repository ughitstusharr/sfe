import { Link } from 'wouter';

export default function MobileNav() {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-slate-200 py-2 px-6 flex justify-between items-center">
      <Link href="/discover" className="flex flex-col items-center text-slate-500 hover:text-primary">
        <i className="ri-compass-3-line text-xl"></i>
        <span className="text-xs mt-1">Discover</span>
      </Link>
      <Link href="/file-share" className="flex flex-col items-center text-slate-500 hover:text-primary">
        <i className="ri-file-transfer-line text-xl"></i>
        <span className="text-xs mt-1">Share</span>
      </Link>
      <Link href="/create" className="flex flex-col items-center text-white bg-primary hover:bg-primary/90 p-3 rounded-full -mt-6 shadow-lg">
        <i className="ri-add-line text-xl"></i>
      </Link>
      <Link href="/dashboard" className="flex flex-col items-center text-slate-500 hover:text-primary">
        <i className="ri-gamepad-line text-xl"></i>
        <span className="text-xs mt-1">My Games</span>
      </Link>
      <Link href="/profile" className="flex flex-col items-center text-slate-500 hover:text-primary">
        <i className="ri-user-line text-xl"></i>
        <span className="text-xs mt-1">Profile</span>
      </Link>
    </div>
  );
}

import { Link } from 'wouter';

export default function HowItWorks() {
  return (
    <section className="py-16 px-4 bg-slate-50">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold font-game text-center mb-4">How It Works</h2>
        <p className="text-slate-600 text-center max-w-2xl mx-auto mb-12">
          Creating and sharing your own game levels is easy! Just follow these simple steps:
        </p>
        
        <div className="grid md:grid-cols-3 gap-8">
          {/* Step 1 */}
          <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all border border-slate-200 relative">
            <div className="absolute -top-5 left-5 bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold">1</div>
            <h3 className="font-game font-bold text-xl mb-4 mt-3">Create Your Level</h3>
            <p className="text-slate-600 mb-4">
              Use our intuitive drag-and-drop editor to design unique game levels with obstacles, enemies, and challenges.
            </p>
            <div className="text-primary font-medium mt-auto">
              <Link href="/create" className="inline-flex items-center">
                Get Started <i className="ri-arrow-right-line ml-1"></i>
              </Link>
            </div>
          </div>
          
          {/* Step 2 */}
          <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all border border-slate-200 relative">
            <div className="absolute -top-5 left-5 bg-secondary text-white w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold">2</div>
            <h3 className="font-game font-bold text-xl mb-4 mt-3">Publish & Share</h3>
            <p className="text-slate-600 mb-4">
              Publish your creation to our platform and share the link with friends and coworkers to challenge them.
            </p>
            <div className="text-primary font-medium mt-auto">
              <Link href="/publish" className="inline-flex items-center">
                Learn More <i className="ri-arrow-right-line ml-1"></i>
              </Link>
            </div>
          </div>
          
          {/* Step 3 */}
          <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all border border-slate-200 relative">
            <div className="absolute -top-5 left-5 bg-purple-500 text-white w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold">3</div>
            <h3 className="font-game font-bold text-xl mb-4 mt-3">Play & Compete</h3>
            <p className="text-slate-600 mb-4">
              Play levels created by others, compete for high scores, and climb the leaderboard during your lunch breaks.
            </p>
            <div className="text-primary font-medium mt-auto">
              <Link href="/leaderboard" className="inline-flex items-center">
                View Leaderboard <i className="ri-arrow-right-line ml-1"></i>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import { Link } from 'wouter';
import GameCard from './GameCard';

// Example game data for presentation
const featuredGames = [
  {
    id: "lunch-rush",
    title: "Lunch Rush",
    description: "Race against time to collect all food items before lunch break ends!",
    category: "Platformer",
    rating: 4.8,
    creatorName: "Alex"
  },
  {
    id: "office-escape",
    title: "Office Escape",
    description: "Solve puzzles to escape your virtual office before the meeting starts!",
    category: "Puzzle",
    rating: 4.6,
    creatorName: "Sarah"
  },
  {
    id: "coffee-cart",
    title: "Coffee Cart",
    description: "Race your coffee cart through the office to deliver drinks before they cool!",
    category: "Racing",
    rating: 4.9,
    creatorName: "Mark"
  }
];

export default function FeaturedGames() {
  return (
    <section className="py-16 px-4 bg-white dot-pattern">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-10">
          <h2 className="text-3xl font-bold font-game">Featured Games</h2>
          <Link href="/discover" className="text-primary hover:text-primary/90 font-medium flex items-center">
            View All <i className="ri-arrow-right-line ml-1"></i>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredGames.map((game) => (
            <GameCard
              key={game.id}
              id={game.id}
              title={game.title}
              description={game.description}
              category={game.category}
              rating={game.rating}
              creatorName={game.creatorName}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

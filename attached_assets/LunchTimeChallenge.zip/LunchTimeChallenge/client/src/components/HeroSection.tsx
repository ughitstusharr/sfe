import { Link } from 'wouter';

export default function HeroSection() {
  return (
    <section className="pt-10 pb-20 px-4 md:pt-16 md:pb-24 overflow-hidden game-pattern">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="text-center md:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-game tracking-tight mb-6">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
                Turn Lunch Breaks
              </span>
              <br />into Game Time
            </h1>
            <p className="text-lg md:text-xl text-slate-600 mb-8 max-w-lg mx-auto md:mx-0">
              Create, share, and play custom game levels with your coworkers. Transform your lunch break into a creative playground!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <Link href="/sign-up" className="px-6 py-3 bg-primary hover:bg-primary/90 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
                Start Creating
              </Link>
              <Link href="/discover" className="px-6 py-3 bg-white hover:bg-slate-50 text-slate-800 font-medium rounded-lg shadow border border-slate-200 hover:border-slate-300 transition-all">
                Browse Games
              </Link>
            </div>
            <div className="mt-8 flex items-center justify-center md:justify-start">
              <div className="flex -space-x-2">
                {/* User avatars representation */}
                <div className="w-10 h-10 rounded-full border-2 border-white bg-slate-300"></div>
                <div className="w-10 h-10 rounded-full border-2 border-white bg-slate-400"></div>
                <div className="w-10 h-10 rounded-full border-2 border-white bg-slate-500"></div>
              </div>
              <span className="ml-4 text-slate-600">
                Join <span className="font-bold text-primary">5,000+</span> players today!
              </span>
            </div>
          </div>
          <div className="relative">
            <div className="relative z-10 bg-white rounded-2xl overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-300">
              <div className="h-48 bg-slate-200"></div>
              <div className="p-6 bg-white">
                <h3 className="font-game font-bold text-xl mb-2">Level Editor Pro</h3>
                <p className="text-slate-600 mb-4">Create custom obstacles, traps, and challenges with our intuitive drag-and-drop editor.</p>
                <div className="flex justify-between items-center">
                  <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Easy to Learn</span>
                  <button className="text-primary hover:text-primary-600 font-medium">Try Now →</button>
                </div>
              </div>
            </div>
            <div className="absolute -top-6 -right-6 w-32 h-32 bg-secondary rounded-full blur-3xl opacity-30 animate-pulse-slow"></div>
            <div className="absolute bottom-6 -left-6 w-32 h-32 bg-primary rounded-full blur-3xl opacity-20 animate-pulse-slow"></div>
          </div>
        </div>
      </div>
    </section>
  );
}

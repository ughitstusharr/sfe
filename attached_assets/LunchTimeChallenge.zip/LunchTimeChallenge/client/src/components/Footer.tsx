import { Link } from 'wouter';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link href="/" className="text-2xl font-bold text-white flex items-center mb-4">
              <i className="ri-gamepad-line text-primary mr-2 text-3xl"></i>
              <span className="font-game">SecureShare</span>
            </Link>
            <p className="text-slate-400 mb-4">
              Transform your lunch breaks into a creative gaming experience with coworkers.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-primary transition-colors">
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="#" className="text-slate-400 hover:text-primary transition-colors">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="text-slate-400 hover:text-primary transition-colors">
                <i className="ri-instagram-fill text-xl"></i>
              </a>
              <a href="#" className="text-slate-400 hover:text-primary transition-colors">
                <i className="ri-github-fill text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Product</h3>
            <ul className="space-y-2">
              <li><Link href="/features" className="text-slate-400 hover:text-primary transition-colors">Features</Link></li>
              <li><Link href="/pricing" className="text-slate-400 hover:text-primary transition-colors">Pricing</Link></li>
              <li><Link href="/testimonials" className="text-slate-400 hover:text-primary transition-colors">Testimonials</Link></li>
              <li><Link href="/faq" className="text-slate-400 hover:text-primary transition-colors">FAQ</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><Link href="/blog" className="text-slate-400 hover:text-primary transition-colors">Blog</Link></li>
              <li><Link href="/tutorials" className="text-slate-400 hover:text-primary transition-colors">Tutorials</Link></li>
              <li><Link href="/documentation" className="text-slate-400 hover:text-primary transition-colors">Documentation</Link></li>
              <li><Link href="/community" className="text-slate-400 hover:text-primary transition-colors">Community</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Company</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-slate-400 hover:text-primary transition-colors">About Us</Link></li>
              <li><Link href="/careers" className="text-slate-400 hover:text-primary transition-colors">Careers</Link></li>
              <li><Link href="/privacy" className="text-slate-400 hover:text-primary transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms" className="text-slate-400 hover:text-primary transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-800 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-slate-500 text-sm">© 2023 SecureShare. All rights reserved.</p>
          <div className="mt-4 md:mt-0">
            <select className="bg-slate-800 border border-slate-700 text-slate-300 py-1 px-3 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary">
              <option value="en">English</option>
              <option value="es">Español</option>
              <option value="fr">Français</option>
              <option value="de">Deutsch</option>
            </select>
          </div>
        </div>
      </div>
    </footer>
  );
}

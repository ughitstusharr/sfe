import { ReactNode } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import MobileNav from './MobileNav';

interface LayoutProps {
  children: ReactNode;
  hideFooter?: boolean;
  isLandingPage?: boolean;
}

export default function Layout({ children, hideFooter = false, isLandingPage = false }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar isLandingPage={isLandingPage} />
      <main className="flex-grow">
        {children}
      </main>
      <MobileNav />
      {!hideFooter && <Footer />}
    </div>
  );
}

import { Link } from 'wouter';

export default function Navbar({ isLandingPage = false }) {
  // Removed Clerk auth dependency for demo
  const isSignedIn = false;
  
  return (
    <nav className="sticky top-0 z-50 w-full py-3 px-4 bg-gradient-to-r from-purple-600/10 to-cyan-400/5 backdrop-blur-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="text-2xl font-bold flex items-center">
            <i className="ri-lock-password-line text-primary mr-2 text-3xl"></i>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-cyan-500 font-bold">
              SecureShare
            </span>
          </Link>
        </div>
        
        <div className="hidden md:flex items-center space-x-6">
          <Link href="/discover" className="text-slate-700 hover:text-primary font-medium transition-colors">
            Discover
          </Link>
          <Link href="/dashboard" className="text-slate-700 hover:text-primary font-medium transition-colors">
            My Files
          </Link>
          <Link href="/file-share" className="text-slate-700 hover:text-primary font-medium transition-colors">
            File Sharing
          </Link>
        </div>
        
        <div className="flex items-center gap-4">
          <Link href="/sign-in" className="text-slate-700 hover:text-primary transition-colors font-medium">
            Login
          </Link>
          <Link href="/sign-up" className="bg-gradient-to-r from-purple-600 to-violet-500 hover:opacity-90 text-white px-5 py-2 rounded-lg transition-colors font-medium shadow-sm hover:shadow-md">
            Get Started
          </Link>
        </div>
      </div>
    </nav>
  );
}

import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertFileSchema } from "@shared/schema";
import { z } from "zod";
import crypto from "crypto";
import { SessionData } from "express-session";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }
      
      // Hash the password before storing
      const hashedPassword = crypto
        .createHash("sha256")
        .update(userData.password)
        .digest("hex");
      
      const user = await storage.createUser({ 
        ...userData, 
        password: hashedPassword 
      });
      
      // Return user data without the password
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ error: "Invalid username or password" });
      }
      
      // Hash the provided password and compare with stored hash
      const hashedPassword = crypto
        .createHash("sha256")
        .update(password)
        .digest("hex");
      
      if (user.password !== hashedPassword) {
        return res.status(401).json({ error: "Invalid username or password" });
      }
      
      // Set user in session
      if (req.session) {
        req.session.userId = user.id;
      }
      
      // Return user data without the password
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
  app.post("/api/auth/logout", (req, res) => {
    if (req.session) {
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json({ error: "Failed to logout" });
        }
        res.clearCookie("connect.sid");
        res.status(200).json({ message: "Logged out successfully" });
      });
    } else {
      res.status(200).json({ message: "Already logged out" });
    }
  });
  
  // Middleware to check if user is authenticated
  const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
    if (!req.session || req.session.userId === undefined) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    next();
  };
  
  // File sharing routes
  app.post("/api/files", isAuthenticated, async (req, res) => {
    try {
      const { fileName, encryptedContent, expiresAt } = req.body;
      
      if (!fileName || !encryptedContent) {
        return res.status(400).json({ error: "File name and content are required" });
      }
      
      // We know userId exists because of the isAuthenticated middleware
      const userId = req.session!.userId as number;
      
      const file = await storage.createFile({
        fileName,
        encryptedContent,
        userId,
        expiresAt: expiresAt ? new Date(expiresAt) : undefined,
      });
      
      res.status(201).json(file);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
  app.get("/api/files", isAuthenticated, async (req, res) => {
    try {
      // We know userId exists because of the isAuthenticated middleware
      // Assert the type as number since we've already checked in isAuthenticated
      const userId = req.session!.userId as number;
      
      const files = await storage.getUserFiles(userId);
      res.json(files);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
  app.get("/api/files/:id", isAuthenticated, async (req, res) => {
    try {
      const file = await storage.getFile(req.params.id);
      
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      
      // Check if user has access to this file
      const userId = req.session!.userId as number;
      if (file.userId !== userId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      res.json(file);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
  app.get("/api/share/:accessKey", async (req, res) => {
    try {
      const file = await storage.getFileByAccessKey(req.params.accessKey);
      
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      
      // Check if file has expired
      if (file.expiresAt && new Date(file.expiresAt) < new Date()) {
        return res.status(410).json({ error: "File has expired" });
      }
      
      // Increment download count
      await storage.incrementDownloadCount(file.id);
      
      res.json({
        fileName: file.fileName,
        encryptedContent: file.encryptedContent,
        downloads: file.downloads + 1
      });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

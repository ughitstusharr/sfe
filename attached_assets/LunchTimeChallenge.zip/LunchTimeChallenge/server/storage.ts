import { type User, type InsertUser } from "@shared/schema";
import crypto from 'crypto';

// Storage interface
export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // File operations
  createFile(file: { fileName: string, encryptedContent: string, userId: number, expiresAt?: Date }): Promise<any>;
  getFile(id: string): Promise<any | undefined>;
  getFileByAccessKey(accessKey: string): Promise<any | undefined>;
  incrementDownloadCount(id: string): Promise<void>;
  getUserFiles(userId: number): Promise<any[]>;
}

// In-memory implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private files: Map<string, any>;
  private filesByAccessKey: Map<string, string>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.files = new Map();
    this.filesByAccessKey = new Map();
    this.currentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }

  // File methods
  async createFile(fileData: { fileName: string, encryptedContent: string, userId: number, expiresAt?: Date }): Promise<any> {
    // Generate a unique ID and access key
    const id = crypto.randomUUID();
    const accessKey = crypto.randomBytes(32).toString('hex');
    const createdAt = new Date();
    
    const file = {
      id,
      fileName: fileData.fileName,
      encryptedContent: fileData.encryptedContent,
      userId: fileData.userId,
      createdAt,
      expiresAt: fileData.expiresAt,
      downloads: 0,
      accessKey
    };
    
    this.files.set(id, file);
    this.filesByAccessKey.set(accessKey, id);
      
    return file;
  }

  async getFile(id: string): Promise<any | undefined> {
    return this.files.get(id);
  }

  async getFileByAccessKey(accessKey: string): Promise<any | undefined> {
    const fileId = this.filesByAccessKey.get(accessKey);
    if (!fileId) return undefined;
    return this.files.get(fileId);
  }

  async incrementDownloadCount(id: string): Promise<void> {
    const file = this.files.get(id);
    if (file) {
      file.downloads += 1;
      this.files.set(id, file);
    }
  }

  async getUserFiles(userId: number): Promise<any[]> {
    if (userId === undefined) {
      throw new Error("User ID is required");
    }
    return Array.from(this.files.values()).filter(file => file.userId === userId);
  }
}

// Export singleton instance of the storage
export const storage = new MemStorage();
